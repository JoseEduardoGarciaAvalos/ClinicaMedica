<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CLÍNICA MÉDICA  </title>


  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">

  <link rel="stylesheet" href="{{asset('css/bootstrap-select.min.css')}}">


  <!-- Font Awesome -->
  <link rel="stylesheet" href="{{asset('css/font-awesome.css')}}">
  <!-- Theme style -->
  <link rel="stylesheet" href="{{asset('css/AdminLTE.min.css')}}">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
     folder instead of downloading all of them to reduce the load. -->
     <link rel="stylesheet" href="{{asset('css/_all-skins.min.css')}}">
     <link rel="apple-touch-icon" href="{{asset('img/apple-touch-icon.png')}}">
     <link rel="shortcut icon" href="{{asset('img/favicon.ico')}}">

     <style type="text/css">
       .modal {
        text-align: center;
        padding: 0!important;
      }

      .modal:before {
        content: '';
        display: inline-block;
        height: 100%;
        vertical-align: middle;
        margin-right: -4px;
      }

      .modal-dialog {
        display: inline-block;
        text-align: left;
        vertical-align: middle;
      }

      .fixed_header{
        width: auto;
        table-layout: fixed;
        border-collapse: collapse;
      }

      .fixed_header tbody{
        display:block;
        width: 100%;
        overflow: auto;
        height: 100px;
      }

      .fixed_header thead tr {
       display: block;
     }

     .fixed_header thead {
      background: blue;
      color:#fff;
    }

    .fixed_header th, .fixed_header td {
      padding: 5px;
      text-align: left;
      width: 200px;
    }

  </style>

</head>
<body class="hold-transition skin-purple-light  sidebar-mini">
  <div class="wrapper">

    <header class="main-header">

      <!-- Logo -->
      <a href="index2.html" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>CMS</b>R</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>SisClínica</b></span>
      </a>

      <!-- Header Navbar: style can be found in header.less -->
      <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
          <span class="sr-only">Navegación</span>
        </a>
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">


            <!-- Messages: style can be found in dropdown.less-->

            <!-- User Account: style can be found in dropdown.less -->

                 <!--<li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                
                <li><a href="{{url('registro/paciente')  }}"><i class="fa fa-male fa-2x" class="text-red" title="Expediente del Paciente"></i></a></li>
               
               <li><a href="{{url('compras/ingreso')  }}"><i class="fa fa-th fa-2x" title="Compra de Medicamentos"></i> </a></li>

               <li><a href="{{url('compras/ingreso')  }}"><i class="fa fa-calendar fa-2x" title="Citas Medicas"></i> </a></li>

               <li><a href="{{url('seguridad/usuario')  }}"><i class="fa fa-edit fa-2x" title="Registro de Usuarios"></i> </a></li>

               <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>
               <span class="sr-only" class="btn btn-success pull-right">Loading...</span>
                  <small class="bg-red">Online</small>
                  <span class="hidden-xs">Azucena Rivas</span>

                </a> -->

                


                
                <!-- <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    Left Side Of Navbar 
                    <ul class="navbar-nav mr-auto">-->





                      <div class="collapse navbar-collapse" id="app-navbar-collapse">


                        <ul class="navbar-nav mr-auto">

                        </ul>
                        
                        <!-- Right Side Of Navbar -->
                        <ul class="navbar-nav ml-auto">
                          <!-- Authentication Links -->
                          @guest
                          <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}"></a>
                          </li>
                            <!--<li class="nav-item">
                                <a class="nav-link" href="{{ route('login') }}">{{ __('Iniciar Sesión') }}</a>
                            </li>

                            <li class="nav-item">
                                @if (Route::has('register'))
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Registrar') }}</a>
                                @endif
                              </li>-->

                              <li class="nav-item">
                                @if (Route::has('register'))
                                <a class="nav-link" href="{{ route('register') }}"></a>
                                @endif
                              </li>
                              @else
                              <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                  {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item" href="{{ route('logout') }}"
                                  onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">
                                  {{ __('Cerrar Sesión ') }}
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                  @csrf
                                </form>
                              </div>
                            </li>
                            @endguest
                          </ul>
                        </div>



                        @if(session('info'))

                        <div class="container">
                          <div class="row">

                            <div class="col-md-8 col-md-offset-2">
                              <div class="alert alert-success">
                                {{ session('info') }}
                              </div>

                            </div>
                          </div>
                        </div>




                        @endif
                <!-- <ul class="dropdown-menu">
                 <li class="user-header">
                 <p>
                 sistemaaa
                 <small>aaaaaaa</small>
                 </p>

                 </li>
                 User image -->
                 
                 <!-- Menu Footer-->
                  <!--<li class="user-footer">
                    
                    <div class="pull-right">
                      <a href="{{url('/logout')}}" class="btn btn-default btn-flat">Cerrar</a>
                    </div>
                  </li>
                </ul>-->
              </li>
              
            </ul>
          </div>

        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header"></li>
            
            <li class="treeview">
              <a href="#">
                <i class="fa fa-male"> </i>
                <!-- <img src="img/paciente.ico" alt="" >-->
                <span>Paciente</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('registro/paciente')  }}"><i class="fa fa-edit"></i> Expediente</a></li>
              </ul>
            </li>

            <li class="treeview">
              <a href="#">
                <i class="fa fa-user-md"></i>
                <span>Consultas</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="almacen/articulo"><i class="fa fa-stethoscope"></i> Médica</a></li>
                <li><a href="almacen/categoria"><i class="fa fa-clipboard"></i> Psicológica</a></li>
                <li><a href="almacen/categoria"><i class="fa fa-calendar"></i> Citas</a></li>
                <li><a href="{{url('tratamientos/tratamiento')  }}"><i class="fa fa-medkit"></i> Tratamiento</a></li>
              </ul>
            </li>

            <li class="treeview">
              <a href="#">
                <i class="fa fa-flask"></i>
                <span>Laboratorio Clínico</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="almacen/articulo"><i class="fa fa-file"></i> Toma de Muestras</a></li>
                <li><a href="almacen/categoria"><i class="fa fa-check-circle"></i> Resultados</a></li>
              </ul>
            </li>

            <li class="treeview">
              <a href="#">
                <i class="fa fa-medkit"></i>
                <span>Farmacia</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('proveedor/producto')  }}"><i class="fa fa-ban"></i> Productos</a></li>
                <li><a href="{{url('proveedor/presentacion')  }}"><i class="fa fa-ban"></i> Presentacion</a></li>
                <li><a href="{{url('proveedor/registro')  }}"><i class="fa fa-users"></i> Proveedores</a></li>
              </ul>
            </li>
            
            <li class="treeview">
              <a href="#">
                <i class="fa fa-th"></i>
                <span>Compras</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('compras/ingreso')}}"><i class="fa fa-edit"></i>  Ingresos</a></li>

                
                
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-shopping-cart"></i>
                <span>Ventas</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('ventas/venta')  }}"><i class="fa fa-shopping-cart"></i> Ventas</a></li>
                <li><a href="ventas/cliente"><i class="fa fa-user"></i> Clientes</a></li>
              </ul>
            </li>

            <li class="treeview">
              <a href="#">
                <i class="fa fa-user"></i>
                <span>Usuarios</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{ route('users.index') }}"><i class="fa fa-user"></i> Usuario</a></li>

                <li><a href="{{ route('roles.index') }}"><i class="fa fa-user"></i> Roles</a></li>
              </ul>
            </li>
            
            
            <li>
              <a href="#">
                <i class="fa fa-question-circle"></i> <span>Ayuda</span>
                <small class="label pull-right bg-red">PDF</small>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="fa fa-info-circle"></i> <span>Acerca De...</span>
                <small class="label pull-right bg-yellow">IT</small>
              </a>
            </li>
            
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!--aca empieza-->
      <!--<nav class="navbar navbar-default" role="navigation">-->
  <!-- El logotipo y el icono que despliega el menú se agrupan
   para mostrarlos mejor en los dispositivos móviles -->
   
  <!-- Agrupar los enlaces de navegación, los formularios y cualquier
   otro elemento que se pueda ocultar al minimizar la barra -->
   
   <!--</nav>-->
   <!--aca termina-->




   <!--Contenido-->
   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title" class="text-danger">Clínica Médica Santa Rosa</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                
                <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-12">
                  <!--Contenido-->

                  
                  @yield('content')
                              <!--Fin Contenido
                                <body background = {{asset ('img/2.jpg')}}
                                style="background-size:700px";
                                style="background-position:50px 200px ";
                                 >

                               <img src={{asset ('img/2.jpg')}} margin-top: 90px"  gn=left >

                             </body>-->

                             <body background = {{asset ('img/Hospital.jpg')}}
                             style="background-size:1100px";
                             style="background-position:absolute ";
                             


                             >



                           </div>
                         </div>
                         
                       </div>
                     </div><!-- /.row -->
                   </div><!-- /.box-body -->
                 </div><!-- /.box -->
               </div><!-- /.col -->
             </div><!-- /.row -->

           </section><!-- /.content -->
         </div><!-- /.content-wrapper -->
         <!--Fin-Contenido-->
         <footer class="main-footer">
          <strong>Copyright &copy; </strong> All rights reserved UES.
        </footer>

        
        
        <!-- jQuery 2.1.4 -->
        <script src="{{asset('js/jQuery-2.1.4.min.js')}}"></script>


        @stack('scripts')
        
        {!!Html::script('js/jQuery-2.1.4.min.js')!!}
        {!!Html::script('js/jquery.mask.min.js')!!}

        <script> function getFormData(form) {
          var unindexed_array = form.serializeArray();
          var indexed_array = {};
          $.map(unindexed_array, function(n, i) {
            indexed_array[n['name']] = n['value'];
          });
          return indexed_array;
        }

        function sendFormData(modal,url,type) {
          var formData = getFormData(modal);
          console.log((formData));
          $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });
          $.ajax({
            type: type,
            url: url,
            data: formData,
            dataType: 'json',
            success: function(data) {
              console.log(JSON.stringify(data));
            },
            error: function(data) {
              console.log((data));
              associate_errors(data.errors,modal)
            },
            complete:function (data) {
              console.log('REQUEST:'+JSON.stringify(data));
            },
          });
        }

        function associate_errors(errors, $modal) {
          var list = $('#errors-list');
          list.empty();
          $.each(errors, function(key, value) {
            list.append('<li>' + value[0] + '</li>');
          });
        }
        
        function nuevoUsuario(modal){
      //sendFormData(modal,"{{url('seguridad/usuario') }}" ,"POST");

      console.log(document.getElementById("formUsuario"));
      sendFormData(document.getElementById("formUsuario"),"{{url('seguridad/usuario')}}","POST");

    }

  </script>






  <!-- Bootstrap 3.3.5 -->
  <script src="{{asset('js/bootstrap.min.js')}}"></script>
  <!-- AdminLTE App -->
  <script src="{{asset('js/app.js')}}"></script>
  <script src="{{asset('js/app.min.js')}}"></script>

  <script src="{{asset('js/bootstrap-select.min.js')}}"></script>


  <script>
    $(document).ready(function() {
      $('.solo-letras').keypress(function(e){
        console.log(e.target);
        var inputValue = e.which;
        if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)) { 
          e.preventDefault(); 
        }
      });

      $('.clear-form').on('hidden.bs.modal', function (e) {
        $(this)
        .find("input,textarea,select")
        .val('')
        .end()
        .find("input[type=checkbox], input[type=radio]")
        .prop("checked", "")
        .end();
      });

      $('[data-dismiss=modal]').on('click', function (e) {
        var $t = $(this),
        target = $t[0].href || $t.data("target") || $t.parents('.modal') || [];

        $(target)
        .find("input,textarea,select")
        .val('')
        .end()
        .find("input[type=checkbox], input[type=radio]")
        .prop("checked", "")
        .end();
      });
    });
  </script>

  @include('sweet::alert')







  @section('scripts')


  @show


</body>
</html>
